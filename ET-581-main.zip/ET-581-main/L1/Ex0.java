// First Java Program
public class Ex0 {
  public static void main(String[] args) {

    System.out.println("Hello World");
    
  }
}
