// Arithmatic operation
public class Ex5_arithmetic {
  public static void main(String[] args) {
    // Arithmetic operators
    int a = 10;
    int b = 3;
    // a = a + b;

    System.out.println("a + b = " + (a + b));
    System.out.println("a - b = " + (a - b));
    System.out.println("a * b = " + (a * b));
    System.out.println("a / b = " + (a / b));
    System.out.println("a % b = " + (a % b));
    //System.exit(1);
    

    int myInt = 9;
    double myDouble = 2;
    System.out.println(myInt+myDouble);
    System.out.println(myInt-myDouble);
    System.out.println(myInt*myDouble);
    System.out.println(myInt/myDouble);
    //System.exit(1);

    // 9 % 5 ==>
    // 7 % 4 ==>
    // 10 % 3 ==>
    // 5 % 8 ==>
    // 13 % 7 ==>

    System.out.println(5/2);
    System.out.println(5/2.0);
    System.out.println(5.0/2);
    System.out.println(5/2 + 2.5);
    System.out.println(5.0/2 + 2.5);
    //  operand operator operand

    System.out.println(10%7);
    System.out.println(5%7);
    System.out.println(20%4);
  }
}
