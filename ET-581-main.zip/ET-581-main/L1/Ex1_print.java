// System.ou.print() will print message to console

public class Ex1_print {
  public static void main(String[] args) {
    // print "Hello World" end with new line
    System.out.println("Hello World");
    System.out.println("Hello New York");

    // print "Hello world" without new line
    System.out.print("Hello World");
    System.out.print("Hello nyc");

    System.out.println("Nice to meet you.");
  }
}

