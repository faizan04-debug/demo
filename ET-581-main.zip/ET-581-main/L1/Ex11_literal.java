import java.util.Scanner;

public class Ex11_literal {

    public static void main(String[] args) {
        System.out.println(3.14*10*10);
        System.out.println(3.14*5*5);

        System.out.println(3.1415*10*10);
        System.out.println(3.1415*5*5);
        System.out.println(3.1415*100*100);
        System.out.println(2*3.1415*100);

        double pi = 3.14;
        System.out.println(pi*10*10);
        System.out.println(pi*5*5);

        pi = 3.1415;
        System.out.println(pi*10*10);
        System.out.println(pi*5*5);
        System.out.println(pi*100*100);
        System.out.println(2*pi*100);

    }
}
