

class Ex7_round_error {
    public static void main(String[] args) {
      System.out.println(0.1 * 10);
      System.out.println(0.1 + 0.1);
      System.out.println(0.1 + 0.1 + 0.1);
      System.out.println(0.1 + 0.1 + 0.1 + 0.1);
      System.out.println(0.1 + 0.1 + 0.1 + 0.1 + 0.1);
      System.out.println(0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1);
      System.out.println(0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1);
      System.out.println(0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1);
      System.out.println(0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1);
      System.out.println(0.1 + 0.1 + 0.1 + 0.1 + 0.1
                 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1);
    }
}
